import re
from collections import Counter
from pathlib import Path

# Always find the sample log file beside this Python script.
file_path = Path(__file__).with_name("sample_windows_logs.txt")

pattern = re.compile(
    r"(?P<timestamp>\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}) "
    r"EventID=(?P<event_id>\d+) "
    r"AccountName=(?P<username>\S+) "
    r"SourceIP=(?P<ip>\S+) "
    r"Status=(?P<status>\w+)"
)

if not file_path.exists():
    raise FileNotFoundError(
        f"Could not find {file_path.name}. Keep it in the same folder as log_parser.py."
    )

events = []
with file_path.open("r", encoding="utf-8") as log_file:
    for line_number, line in enumerate(log_file, start=1):
        match = pattern.search(line)
        if match:
            events.append(match.groupdict())
        elif line.strip():
            print(f"Warning: line {line_number} did not match the expected log format.")

failed = [event for event in events if event["event_id"] == "4625"]
successful = [event for event in events if event["event_id"] == "4624"]
failed_by_user = Counter(event["username"] for event in failed)
failed_by_ip = Counter(event["ip"] for event in failed)
threshold = 3

print("\n===== WINDOWS EVENT LOG ANALYSIS =====")
print("Total Events Analysed:", len(events))
print("Failed Login Attempts:", len(failed))
print("Successful Login Attempts:", len(successful))

print("\n===== SUSPICIOUS AUTHENTICATION ACTIVITY =====")
suspicious_found = False
for username, count in failed_by_user.items():
    if count >= threshold:
        suspicious_found = True
        print(f"\nUsername: {username}")
        print(f"Failed Attempts: {count}")
        for event in failed:
            if event["username"] == username:
                print(f"Timestamp: {event['timestamp']} | Event ID: {event['event_id']} | Source IP: {event['ip']}")
        print("Alert: Multiple failed login attempts detected.")

if not suspicious_found:
    print("No suspicious activity detected.")

print("\n===== FAILED ATTEMPTS BY IP ADDRESS =====")
for ip, count in failed_by_ip.items():
    print(f"{ip}: {count} failed attempts")
